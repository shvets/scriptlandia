/*
 * This script is run once when a scripting engine is first created.
 * It's the ideal place to define any extensions to built-in Javascript
 * objects or any new top-level global variables.
 */

(function() {

    // place extension code here
        
})();
