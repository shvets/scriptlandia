module RecipeHelper
end
