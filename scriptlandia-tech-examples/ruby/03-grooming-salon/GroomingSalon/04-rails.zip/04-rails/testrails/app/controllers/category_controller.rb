class CategoryController < ApplicationController
  scaffold :category
end
