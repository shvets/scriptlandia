class ContactTypeController < ApplicationController
	scaffold :contact_type
	
	def destroy
	end
end
