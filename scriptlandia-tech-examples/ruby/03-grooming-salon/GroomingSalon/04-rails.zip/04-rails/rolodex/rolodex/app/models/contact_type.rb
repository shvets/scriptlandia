class ContactType < ActiveRecord::Base
end
