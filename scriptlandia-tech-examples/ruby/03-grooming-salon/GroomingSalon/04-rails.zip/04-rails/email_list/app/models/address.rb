class Address < ActiveRecord::Base
  belongs_to :person
end