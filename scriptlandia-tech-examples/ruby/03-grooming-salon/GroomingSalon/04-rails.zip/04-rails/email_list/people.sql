CREATE TABLE people (
  id int(11) NOT NULL auto_increment,
  first_name varchar(255),
  last_name varchar(255), 
  email varchar(255),
  PRIMARY KEY (id)
);