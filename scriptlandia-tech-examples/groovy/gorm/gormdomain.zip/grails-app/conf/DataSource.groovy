dataSource {
	pooled = true
	driverClassName = 'com.mysql.jdbc.Driver'
	dialect = org.hibernate.dialect.MySQL5InnoDBDialect
}

hibernate {
    cache.use_second_level_cache = true
    cache.use_query_cache = true
    show_sql = false
    cache.provider_class = 'org.hibernate.cache.EhCacheProvider'
}

// environment specific settings
environments {
	development {
		dataSource {
			url = 'jdbc:mysql://localhost/gorm'
			username = 'gorm'
			password = 'gorm'
			dbCreate = 'create-drop'
		}
	}
	test {
		dataSource {
			dbCreate = 'create-drop'
			driverClassName = 'org.h2.Driver'
			url = 'jdbc:h2:mem:test'
			username = 'sa'
			password = ''
			dialect = org.hibernate.dialect.H2Dialect
		}
	}
	production {
		dataSource {
			dbCreate = 'create-drop'
			url = 'jdbc:mysql://localhost/gorm'
			username = 'gorm'
			password = 'gorm'
		}
	}
}
