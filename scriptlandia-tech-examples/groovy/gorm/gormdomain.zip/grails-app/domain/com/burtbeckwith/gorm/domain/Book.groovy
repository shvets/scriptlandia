package com.burtbeckwith.gorm.domain

class Book {

	String title
	String author

	String toString() {
		return "$title by $author"
	}
}
