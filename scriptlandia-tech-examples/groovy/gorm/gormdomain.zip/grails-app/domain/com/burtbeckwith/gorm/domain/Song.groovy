package com.burtbeckwith.gorm.domain

class Song {

	String title
	String artist
	String albumName
}
