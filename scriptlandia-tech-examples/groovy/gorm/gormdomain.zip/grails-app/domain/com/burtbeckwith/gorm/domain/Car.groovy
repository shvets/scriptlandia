package com.burtbeckwith.gorm.domain

class Car {

	String make
	String model
	String year
	String vin

	String toString() {
		return "$year $make $model $vin"
	}
}
