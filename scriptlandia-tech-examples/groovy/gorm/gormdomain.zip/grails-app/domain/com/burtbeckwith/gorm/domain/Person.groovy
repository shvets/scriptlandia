package com.burtbeckwith.gorm.domain

class Person {

	String firstName
	String lastName
	Date dateOfBirth

	String toString() {
		return "$firstName $lastName ($dateOfBirth)"
	}
}