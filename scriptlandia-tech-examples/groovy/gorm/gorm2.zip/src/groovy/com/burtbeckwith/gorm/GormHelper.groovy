package com.burtbeckwith.gorm

import org.codehaus.groovy.grails.commons.DefaultGrailsApplication
import org.codehaus.groovy.grails.orm.hibernate.cfg.GrailsAnnotationConfiguration
import org.codehaus.groovy.grails.plugins.orm.hibernate.HibernateGrailsPlugin
import org.codehaus.groovy.grails.plugins.DomainClassGrailsPlugin

import org.springframework.orm.hibernate3.HibernateTransactionManager
import org.springframework.transaction.support.TransactionCallback
import org.springframework.transaction.support.TransactionTemplate

/**
 * Initializes GORM and has public fields for the Application, SessionFactory,
 * and TransactionManager.
 *
 * Based on code from http://jweldin.com/blog/?p=6, updated to work with Grails 1.0.x.
 *
 * @author Burt
 */
class GormHelper {

	/**
	 * The application.
	 */
	static def application

	/**
	 * The Hibernate SessionFactory.
	 */
	static def sessionFactory

	/**
	 * The Hibernate TransactionManager.
	 */
	static def transactionManager

	private static TransactionTemplate transactionTemplate
	private static boolean _initialized

	private GormHelper() {
		// static only
	}

	/**
	 * Configure GORM. Only call once.
	 */
	static synchronized void initialize() {
		if (_initialized) {
			return
		}
		new GormHelper().doInitialize()
		_initialized = true
	}

	private void doInitialize() {

		ExpandoMetaClassCreationHandle.enable()

		buildApplication()

		def configuration = buildConfiguration()

		sessionFactory = configuration.buildSessionFactory()

		transactionManager = new HibernateTransactionManager(sessionFactory: sessionFactory)

		transactionTemplate = new TransactionTemplate(transactionManager)

		wireUpMethods()
	}

	private void buildApplication() {
		def domainClasses = []
		getResource('domainclasses.txt').text.eachLine { className ->
			domainClasses << loadClass(className)
		}

		application = new DefaultGrailsApplication(
				domainClasses as Class[],
				new GroovyClassLoader(classLoader))
		application.initialise()
	}

	private void wireUpMethods() {

		def ctx = new FakeApplicationContext(
				transactionManager: transactionManager,
				sessionFactory: sessionFactory)

		Closure c = new DomainClassGrailsPlugin().doWithDynamicMethods
		c.delegate = [application: application]
		c.call ctx

		c = new HibernateGrailsPlugin().doWithDynamicMethods
		c.delegate = [application: application]
		c.call ctx
	}

	private def buildConfiguration() {

		def configuration = new GrailsAnnotationConfiguration(
				grailsApplication: application)
		loadProperties configuration

		URL hibernateCfgXml = getResource(
				'grails-app/conf/hibernate/hibernate.cfg.xml')
		if (hibernateCfgXml) {
			configuration.configure(hibernateCfgXml)
		}

		return configuration
	}

	private void loadProperties(configuration) {
		Properties properties = new Properties()
		String grailsEnv = System.getProperty('grails.env') ?: 'production'

		def dsConfig = new ConfigSlurper(grailsEnv).parse(loadClass('DataSource'))
		properties.'hibernate.connection.username' = dsConfig.dataSource.username
		properties.'hibernate.connection.password' = dsConfig.dataSource.password
		properties.'hibernate.connection.url' = dsConfig.dataSource.url
		properties.'hibernate.connection.driver_class' = dsConfig.dataSource.driverClassName

		if (dsConfig.dataSource.dbCreate) {
			properties.'hibernate.hbm2ddl.auto' = dsConfig.dataSource.dbCreate
		}

		def dialect = dsConfig.dataSource.dialect
		if (dialect instanceof Class) {
			dialect = dialect.name
		}
		properties.'hibernate.dialect' = dialect // no autodetect, must set

		configuration.properties = properties
	}

	private ClassLoader getClassLoader() {
		getClass().classLoader
	}

	private Class loadClass(name) {
		classLoader.loadClass(name)
	}

	private URL getResource(name) {
		classLoader.getResource(name)
	}

	/**
	 * Execute a closure in a transaction.
	 * @param callable  the closure to invokes
	 */
	static void withTransaction(Closure callable) {
		transactionTemplate.execute({status ->
			callable.call(status)
		} as TransactionCallback)
	}
}
