package com.burtbeckwith.gorm

import org.springframework.context.support.GenericApplicationContext

/**
 * Used as a mock when calling HibernateGrailsPlugin.
 *
 * @author Burt
 */
class FakeApplicationContext extends GenericApplicationContext {
	def transactionManager
	def sessionFactory
}
