package com.burtbeckwith.gorm.swing

import groovy.swing.SwingBuilder

import javax.swing.WindowConstantsimport javax.swing.BoxLayout
import com.burtbeckwith.gorm.GormHelper
import com.burtbeckwith.gorm.domain.*
class MainFrame {

	MainFrame() {

		def books
		def cars
		def people

		GormHelper.withTransaction { status ->
			// the transaction isn't required here, but would be if the
			// domain classes had lazy-loaded associations 
			books = Book.list()
			cars = Car.list()
			people = Person.list()
		}

		new SwingBuilder().frame(
			title: 'GORM in Swing',
			size: [700, 500],
			visible: true,
			defaultCloseOperation: WindowConstants.EXIT_ON_CLOSE) {

				boxLayout(axis: BoxLayout.Y_AXIS)

				scrollPane {
					table() {
						tableModel(list: books) {
							propertyColumn(header: 'Title', propertyName: 'title')
							propertyColumn(header: 'Author', propertyName: 'author')
						}
					}
				}

				scrollPane {
					table() {
						tableModel(list: cars) {
							propertyColumn(header: 'Make', propertyName: 'make')
							propertyColumn(header: 'Model', propertyName: 'model')
							propertyColumn(header: 'Year', propertyName: 'year')
							propertyColumn(header: 'VIN', propertyName: 'vin')
						}
					}
				}

				scrollPane {
					table() {
						tableModel(list: people) {
							propertyColumn(header: 'First Name', propertyName: 'firstName')
							propertyColumn(header: 'Last Name', propertyName: 'lastName')
							propertyColumn(header: 'DOB', propertyName: 'dateOfBirth')
						}
					}
				}
			}
	}
}
