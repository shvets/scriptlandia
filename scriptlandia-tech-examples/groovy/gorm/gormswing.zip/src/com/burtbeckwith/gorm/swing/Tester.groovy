package com.burtbeckwith.gorm.swing

import com.burtbeckwith.gorm.domain.*
import com.burtbeckwith.gorm.GormHelper

class Tester {

	static void main(String[] args) {

		GormHelper.initialize()

		GormHelper.withTransaction { status ->

			createBook "The Dark Tower: The Gunslinger", "Stephen King"
			createBook "Accounting For Dummies, 3rd Edition", "John A. Tracy"
			createBook "It", "Stephen King"

			createCar "Hyundai", "Tiburon", "2006", "SOMELONGVINNUMBER"
			createCar "Dodge", "Neon", "2001", "SOMEOTHERLONGVINNUMBER"

			createPerson "Jeremie", "Weldin", new Date()
			createPerson "John", "Doe", new Date() - 450

			println "\nAll of the books:"
			Book.list().each { println "\t$it" }

			println "\nAll of the cars:"
			Car.list().each { println "\t$it" }

			println "\nAll of the people:"
			Person.list().each { println "\t$it" }

			println "\nAll of the books by Stephen King:"
			Book.findAllByAuthor("Stephen King").each { println "\t$it" }

			println "\nAll of the books ordered by name:"
			Book.listOrderByTitle().each { println "\t$it" }
		}
	}

	private static void createBook(title, author) {
		Book b = new Book(title: title, author: author).save()
		println "Added book: $b"
	}

	private static void createCar(make, model, year, vin) {
		Car c = new Car(make: make, model: model, year: year, vin: vin).save()
		println "Added car: $c"
	}

	private static void createPerson(firstName, lastName, dateOfBirth) {
		Person p = new Person(firstName: firstName, lastName: lastName, dateOfBirth: dateOfBirth).save()
		println "Added person: $p"
	}
}
